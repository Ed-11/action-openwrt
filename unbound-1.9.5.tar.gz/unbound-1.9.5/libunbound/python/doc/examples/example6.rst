.. _example_localzone:

Local zone manipulation
=======================

This example program shows how to define local zone containing custom DNS
records.

Source code
-----------

.. literalinclude:: example6-1.py
    :language: python
