echo " ---[ IPsec external hook FAIL; only care if ipsecmod-strict: yes ]---"
exit 1
